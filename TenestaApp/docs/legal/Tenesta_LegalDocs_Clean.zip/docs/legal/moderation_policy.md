# Moderation Policy

Tenesta investigates user reports of abuse, fraud, and inappropriate behavior. Users who violate platform guidelines may receive warnings, be temporarily suspended, or be banned depending on the severity of the issue.

All reports are reviewed by our Trust & Safety team. Users can appeal enforcement decisions by emailing appeals@tenesta.com.
