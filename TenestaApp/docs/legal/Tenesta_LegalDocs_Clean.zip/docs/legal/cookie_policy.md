# Cookie Policy

Tenesta uses cookies to provide core functionality and analyze usage. Users can manage cookie preferences through their browser. Non-essential cookies used for analytics or advertising will require user consent in applicable regions.

We comply with GDPR, CCPA, and other international privacy frameworks. Questions can be directed to privacy@tenesta.com.
