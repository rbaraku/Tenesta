# API Usage Policy

Access to the Tenesta API is limited to approved partners and integrations. API keys must not be shared. Excessive usage, scraping, or misuse of endpoints may result in revoked access or legal action.

API access requests can be sent to integrations@tenesta.com.
