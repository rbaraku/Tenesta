# Acceptable Use Policy

Effective Date: August 2, 2025

Tenesta users are expected to act professionally and respectfully. Misuse of the platform includes harassment, discrimination, fraud, threats, and posting or sharing false information. Automated scraping or bypassing access controls is also prohibited.

Violations may result in warnings, temporary suspensions, or permanent bans. Reports of abuse can be sent to trust@tenesta.com.
