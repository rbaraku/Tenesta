# Data Privacy Policy

Effective Date: August 2, 2025

This policy explains how Tenesta handles user data in compliance with GDPR, CCPA, and other privacy regulations. All personal data is encrypted and only used to operate our services. We do not sell user data under any circumstances.

Users have the right to access, correct, or delete their data. Requests can be submitted at privacy@tenesta.com. In the event of a breach, affected users and regulators will be notified within the required legal timeframe.
