# Accessibility Statement

Tenesta is designed to be accessible to all users, including those with disabilities. Our goal is to comply with WCAG 2.1 Level AA standards and applicable accessibility laws.

We support keyboard navigation, screen readers, high-contrast modes, and mobile accessibility. Feedback can be submitted to accessibility@tenesta.com.
