# Data Breach Response Plan

Tenesta has a defined process for handling data breaches:

1. Identify and contain the breach
2. Assess the impact and affected data
3. Notify users and regulators if necessary
4. Apply technical or policy changes to prevent future incidents

All breaches are documented and reviewed. Notifications are made within 72 hours when required by law.
