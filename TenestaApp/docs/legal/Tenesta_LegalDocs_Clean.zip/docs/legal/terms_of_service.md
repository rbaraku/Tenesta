# Terms of Service

Effective Date: August 2, 2025

By using Tenesta, users agree to comply with all platform rules and applicable laws. Providing false information, using the platform for illegal activity, or abusing other users may result in account suspension or termination.

Tenesta is not responsible for interactions between users but provides tools to help resolve disputes. This agreement is governed by the laws of the State of Illinois. For legal questions, contact legal@tenesta.com.
